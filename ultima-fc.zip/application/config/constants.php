<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
|--------------------------------------------------------------------------
| File and Directory Modes
|--------------------------------------------------------------------------
|
| These prefs are used when checking and setting modes when working
| with the file system.  The defaults are fine on servers with proper
| security, but you may wish (or even need) to change the values in
| certain environments (Apache running a separate process for each
| user, PHP under CGI with Apache suEXEC, etc.).  Octal values should
| always be used to set the mode correctly.
|
*/
define('FILE_READ_MODE', 0644);
define('FILE_WRITE_MODE', 0666);
define('DIR_READ_MODE', 0755);
define('DIR_WRITE_MODE', 0755);

/*
|--------------------------------------------------------------------------
| Static BNL
|--------------------------------------------------------------------------
*/
// define('STATIC_BNL', 'https://m.bnltradingcorp.com/');
define('MIN_ENCASH', 50);
define('MAX_ENCASH', 50);
define('MIN_REQUIZA_DEPOSIT', 3500);
define('MAX_REQUIZA_DEPOSIT', 500000);
/*
|--------------------------------------------------------------------------
| Blockchain
|--------------------------------------------------------------------------
*/
define('API_KEY', 'a1441aae-9e2e-4888-9e65-30c56305abcb');
define('XPUB', 'xpub6DDjqr1vNKx95XnDtDNbbyQbz4sHx95QQmXaENuG7KrUEvoiYPQPP5s7GfChGnEKo4JyUhdxQrSQKmoapexwPx9VSmCyVxaARLB17JUKCwc');
define('SECRET', 'ablckchainxcrtcdex');

/*
|--------------------------------------------------------------------------
| CoinPayment
|--------------------------------------------------------------------------
*/
define('COINPAYMENT_MERCHANT_ID', 'bc00aebcacc423859a85b8c87317bbde');
define('COINPAYMENT_SECRET_ID', 'rqzacrtcoinpymntd18');
define('COINPAYMENT_PUBLIC_KEY', 'ae8d11ad57f08b9a1754fd3f0efc5a9e5002c11c8b8936dfa19830418b53dede');
define('COINPAYMENT_PRIVATE_KEY', 'D4520e7c5f4f9778297714Ff00445cbc4Ca59a76e1F05009cDd14eB6F0D221b4');

/*
|--------------------------------------------------------------------------
| File Stream Modes
|--------------------------------------------------------------------------
|
| These modes are used when working with fopen()/popen()
|
*/

define('FOPEN_READ', 'rb');
define('FOPEN_READ_WRITE', 'r+b');
define('FOPEN_WRITE_CREATE_DESTRUCTIVE', 'wb'); // truncates existing file data, use with care
define('FOPEN_READ_WRITE_CREATE_DESTRUCTIVE', 'w+b'); // truncates existing file data, use with care
define('FOPEN_WRITE_CREATE', 'ab');
define('FOPEN_READ_WRITE_CREATE', 'a+b');
define('FOPEN_WRITE_CREATE_STRICT', 'xb');
define('FOPEN_READ_WRITE_CREATE_STRICT', 'x+b');

/*
|--------------------------------------------------------------------------
| Display Debug backtrace
|--------------------------------------------------------------------------
|
| If set to TRUE, a backtrace will be displayed along with php errors. If
| error_reporting is disabled, the backtrace will not display, regardless
| of this setting
|
*/
define('SHOW_DEBUG_BACKTRACE', TRUE);

/*
|--------------------------------------------------------------------------
| Exit Status Codes
|--------------------------------------------------------------------------
|
| Used to indicate the conditions under which the script is exit()ing.
| While there is no universal standard for error codes, there are some
| broad conventions.  Three such conventions are mentioned below, for
| those who wish to make use of them.  The CodeIgniter defaults were
| chosen for the least overlap with these conventions, while still
| leaving room for others to be defined in future versions and user
| applications.
|
| The three main conventions used for determining exit status codes
| are as follows:
|
|    Standard C/C++ Library (stdlibc):
|       http://www.gnu.org/software/libc/manual/html_node/Exit-Status.html
|       (This link also contains other GNU-specific conventions)
|    BSD sysexits.h:
|       http://www.gsp.com/cgi-bin/man.cgi?section=3&topic=sysexits
|    Bash scripting:
|       http://tldp.org/LDP/abs/html/exitcodes.html
|
*/
define('EXIT_SUCCESS', 0); // no errors
define('EXIT_ERROR', 1); // generic error
define('EXIT_CONFIG', 3); // configuration error
define('EXIT_UNKNOWN_FILE', 4); // file not found
define('EXIT_UNKNOWN_CLASS', 5); // unknown class
define('EXIT_UNKNOWN_METHOD', 6); // unknown class member
define('EXIT_USER_INPUT', 7); // invalid user input
define('EXIT_DATABASE', 8); // database error
define('EXIT__AUTO_MIN', 9); // lowest automatically-assigned error code
define('EXIT__AUTO_MAX', 125); // highest automatically-assigned error code

/*
|--------------------------------------------------------------------------
| Asset Libraries
|--------------------------------------------------------------------------
|
| These are libraries of javascript and stylesheet used in the project
|
*/


// Admin Files ----------

/*-- Bootstrap 3.3.7 */
define('BootstrapCSS_admin', 'assets/admin/bower_components/bootstrap/dist/css/bootstrap.min.css');
/*-- Font Awesome */
define('FontAwesomeCSS_admin', 'assets/admin/bower_components/font-awesome/css/font-awesome.min.css');
/*-- Ionicons */
define('IoniconsCSS_admin', 'assets/admin/bower_components/Ionicons/css/ionicons.min.css');
/*-- AdminLTE */
define('AdminLTECSS_admin', 'assets/admin/dist/css/AdminLTE.css');
/*-- Skin style */
define('SkinStyleCSS_admin', 'assets/admin/dist/css/skins/_all-skins.css');
/*-- morris */
define('morriscs_admin', 'assets/admin/bower_components/morris.js/morris.css');
/*-- jvectormap */
define('jvectormap_admin', 'assets/admin/bower_components/jvectormap/jquery-jvectormap.css');
/*-- Date Picker */
define('datePicker_admin', 'assets/admin/bower_components/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css');
define('daterangepickercss_admin', 'assets/admin/bower_components/bootstrap-daterangepicker/daterangepicker.css');
/*-- Datatable */
define('DatatableCSS_admin', 'assets/admin/bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css');
/*-- Hierarchy */
define('HierarchyCSS_admin', 'assets/admin/plugins/hierarchy/css/hierarchy-view.css');
define('HierarchySCSS_admin', 'assets/admin/plugins/hierarchy/scss/hierarchy-view.scss');
/*-- bootstrap wysihtml5 - text editor */
define('wysihtml5_admin', 'assets/admin/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css');
/*-- bootstrap wysihtml5 - text editor */
define('select2css_admin', 'assets/admin/bower_components/select2/dist/css/select2.css');
/*-- blue */
define('blue_admin', 'assets/admin/plugins/iCheck/square/blue.css');


/*-- jQuery 3 */
define('jQuery3JS_admin', 'assets/admin/bower_components/jquery/dist/jquery.min.js');
/*-- jquery UI */
define('jqueryUIJS_admin', 'assets/admin/bower_components/jquery-ui/jquery-ui.min.js');
/*-- Bootstrap 3.3.7 */
define('BootstrapJS_admin', 'assets/admin/bower_components/bootstrap/dist/js/bootstrap.min.js');
/*-- Select */
define('select2js_admin', 'assets/admin/bower_components/select2/dist/js/select2.full.js');
/*-- chart */
define('chartjs_admin', 'assets/admin/bower_components/Chart.js/Chart.js');
/*-- SlimScroll */
define('SlimScrollJS_admin', 'assets/admin/bower_components/jquery-slimscroll/jquery.slimscroll.min.js');
/*-- raphael */
define('raphael_admin', 'assets/admin/bower_components/raphael/raphael.min.js');
/*-- morris */
define('morrisjs_admin', 'assets/admin/bower_components/morris.js/morris.min.js');
/*-- jquery sparkline */
define('sparkline_admin', 'assets/admin/bower_components/jquery-sparkline/dist/jquery.sparkline.min.js');
/*-- jvectormap */
define('jvectormapjs_admin', 'assets/admin/plugins/jvectormap/jquery-jvectormap-1.2.2.min.js');
define('jvectormapworld_admin', 'assets/admin/plugins/jvectormap/jquery-jvectormap-world-mill-en.js');
/*-- jquery knob */
define('jqueryknob_admin', 'assets/admin/bower_components/jquery-knob/dist/jquery.knob.min.js');
/*-- moment */
define('moment_admin', 'assets/admin/bower_components/moment/min/moment.min.js');
/*-- daterangepicker */
define('daterangepickerjs_admin', 'assets/admin/bower_components/bootstrap-daterangepicker/daterangepicker.js');
/*-- datepicker */
define('datepicker_admin', 'assets/admin/bower_components/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js');
/*-- Datatable */
define('DatatableJQueryJS_admin', 'assets/admin/bower_components/datatables.net/js/jquery.dataTables.min.js');
/*-- Datatable Bootsrap*/
define('DatatableBootsrapJS_admin', 'assets/admin/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js');
/*-- Bootstrap WYSIHTML5 */
define('BootstrapWYSIHTM5JS_admin', 'assets/admin/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js');
/*-- fastclick */
define('fastclick_admin', 'assets/admin/bower_components/fastclick/lib/fastclick.js');
/*-- adminlte */
define('adminlte_admin', 'assets/admin/dist/js/adminlte.min.js');
/*-- dashboard */
define('dashboard_admin', 'assets/admin/dist/js/pages/dashboard.js');
/*-- dashboard */
define('customer_admin', 'assets/admin/dist/js/pages/customer.js');
/*-- sales */
define('sales_admin', 'assets/admin/dist/js/pages/sales.js');
/*-- report */
define('report_admin', 'assets/admin/dist/js/pages/report.js');
/*-- item */
define('item_admin', 'assets/admin/dist/js/pages/item.js');
/*-- activity */
define('activity_admin', 'assets/admin/dist/js/pages/activity.js');
/*-- demo */
define('demo_admin', 'assets/admin/dist/js/demo.js');
/*-- icheck */
define('icheck_admin', 'assets/admin/plugins/iCheck/icheck.min.js');
/*-- format number */
define('formatnojs_admin', 'assets/admin/plugins/jquery.formatNumber/jquery.formatNumber-0.1.1.min.js');
/*-- demo */
define('html2canvas_admin', 'assets/admin/plugins/html2canvas/html2canvas.js');
/*-- icheck */
define('jspdf_admin', 'assets/admin/plugins/jspdf/jspdf.min.js');
/*-- format number */
// define('fileSaver_admin', 'assets/admin/plugins/filesaver/fileSaver.js');


// Member Files ----------
// Head
define('MemberMaterial', 'assets/member/css/material-dashboard.css?v=2.1.0');
define('MemberDemo', 'assets/member/demo/demo.css');

// Footer
define('MemberJQuery', 'assets/member/js/core/jquery.min.js');
define('MemberPopper', 'assets/member/js/core/popper.min.js');
define('MemberMaterialDesign', 'assets/member/js/core/bootstrap-material-design.min.js');
define('MemberPerfectScroll', 'assets/member/js/plugins/perfect-scrollbar.jquery.min.js');
define('MemberChartist', 'assets/member/js/plugins/chartist.min.js');
define('MemberMaterialDashboard', 'assets/member/js/material-dashboard.js?v=2.1.0');
define('MemberDemoJs', 'assets/member/demo/demo.js');
define('MemberCustom', 'assets/member/js/custom.js');
