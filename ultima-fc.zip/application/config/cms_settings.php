<?php defined('BASEPATH') OR exit('No direct script access allowed');

$config['cms_title'] = 'CI App';
$config['cms_dev'] = 'youremail@yourdomain.com';

$config['cms_featured_image'] = '400x350';
