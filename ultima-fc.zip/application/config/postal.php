<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
$config['message_types'] = array(
    'success' => array('<div class="alert alert-info alert-dismissible text-center" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>', '</div>'),
    'error' => array('<div class="alert alert-danger alert-dismissible text-center" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>', '</div>'),
    'message' => array('<div class="message text-center">', '</div>'));