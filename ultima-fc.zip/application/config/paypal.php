<?php
/** set your paypal credential **/

$config['client_id'] = 'AWeWY5fsfVa_PklsZPckmeYzpBJS97dIbE_FPBB3xT-NKp2kb9zsSC-spssSXDq2Or1t_uu_47qN_sgt';
$config['secret'] = 'EP_gBzYH2LVJEVqrKfMiYZiz8UbTpD1o-PQnb7zEVArLxmnQAJxnP3vd68RYTV6Gq65hRrrIs4xIUJvZ';

/**
 * SDK configuration
 */
/**
 * Available option 'sandbox' or 'live'
 */
$config['settings'] = array(

    'mode' => 'live',
    /**
     * Specify the max request time in seconds
     */
    'http.ConnectionTimeOut' => 1000,
    /**
     * Whether want to log to a file
     */
    'log.LogEnabled' => true,
    /**
     * Specify the file that want to write on
     */
    'log.FileName' => 'application/logs/paypal.log',
    /**
     * Available option 'FINE', 'INFO', 'WARN' or 'ERROR'
     *
     * Logging is most verbose in the 'FINE' level and decreases as you
     * proceed towards ERROR
     */
    'log.LogLevel' => 'FINE'
);
