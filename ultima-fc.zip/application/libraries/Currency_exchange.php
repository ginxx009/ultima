<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Currency_Exchange {
    private $ci;
    public function __construct()
    {
        $this->ci =& get_instance();
    }

    public function getEURToBTC($amount){
        $currency = 'EUR';
        $url = 'https://bitpay.com/api/rates/'.$currency;
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL,$url);
        curl_setopt($ch, CURLOPT_HTTPHEADER, Array("User-Agent: Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.15) Gecko/20080623 Firefox/2.0.0.15") ); 
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $result= curl_exec ($ch);
        curl_close ($ch);
        $info = json_decode($result, true);
        if (isset($info)) {
            if(array_key_exists("rate",$info)){
                return $amount / $info["rate"];
            }
            else{
                return "server_error";
            }
        }
        else{
            return "server_error";
        }
    }

    public function getEURToPHP($amount){
        $rate = $this->getRatesEURToPHP();
        if ($rate != "server_error") {
            $value = (double) $rate * (double)$amount;
            return number_format((double)$value, 2, '.', '');
        }
        else{
            return "server_error";
        }
    }

    public function getEURToUSD($amount){
        $rate = $this->getRatesEURToUSD();
        if ($rate != "server_error") {
            $value = (double) $rate * (double)$amount;
            return number_format((double)$value, 2, '.', '');
        }
        else{
            return "server_error";
        }
    }

    private function getRatesEURToPHP()
    {
        $url = 'http://api.fixer.io/latest?base=EUR&symbols=PHP';
        $handle = @fopen($url, 'r');
        if ($handle) {
            $result = fgets($handle, 4096);
            fclose($handle);
        }
        if (isset($result)) {
            $conversion = json_decode($result, true);
            if (isset($conversion['rates']['PHP'])) {
                return $conversion['rates']['PHP'];
            }
        }
        return "server_error";
    }

    private function getRatesEURToUSD()
    {
        $url = 'http://api.fixer.io/latest?base=EUR&symbols=USD';
        $handle = @fopen($url, 'r');
        if ($handle) {
            $result = fgets($handle, 4096);
            fclose($handle);
        }
        if (isset($result)) {
            $conversion = json_decode($result, true);
            if (isset($conversion['rates']['USD'])) {
                return $conversion['rates']['USD'];
            }
        }
        return "server_error";
    }
}